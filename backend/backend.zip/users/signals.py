def ready(self):
    import users.signals