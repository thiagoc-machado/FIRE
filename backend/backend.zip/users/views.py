from rest_framework import generics
from drf_spectacular.utils import extend_schema, OpenApiExample
from .serializers import RegisterSerializer
from django.contrib.auth import get_user_model

User = get_user_model()

@extend_schema(
    tags=['Usuários'],
    summary='Registrar novo usuário',
    description='Cria um novo usuário com os dados fornecidos (username, email e senha).',
    examples=[
        OpenApiExample(
            name='Exemplo de registro',
            value={
                'username': 'usuario123',
                'email': 'usuario@example.com',
                'password': 'senhaSegura123'
            },
            request_only=True
        )
    ]
)
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
