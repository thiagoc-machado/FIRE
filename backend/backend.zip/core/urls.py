from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, BrokerViewSet, AssetViewSet, OperationViewSet, DashboardViewSet

router = DefaultRouter()
router.register('categories', CategoryViewSet)
router.register('brokers', BrokerViewSet)
router.register('assets', AssetViewSet)
router.register('operations', OperationViewSet)
router.register(r'dashboard', DashboardViewSet, basename='dashboard')

urlpatterns = router.urls