from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema, OpenApiExample, OpenApiResponse

from .models import Category, Broker, Asset, Operation
from .serializers import CategorySerializer, BrokerSerializer, AssetSerializer, OperationSerializer
from .services.yahoo_service import buscar_dados_ativo


@extend_schema(tags=['Categorias'])
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]


@extend_schema(tags=['Corretoras'])
class BrokerViewSet(viewsets.ModelViewSet):
    queryset = Broker.objects.all()
    serializer_class = BrokerSerializer
    permission_classes = [IsAuthenticated]


@extend_schema(tags=['Ativos'])
class AssetViewSet(viewsets.ModelViewSet):
    queryset = Asset.objects.all()
    serializer_class = AssetSerializer
    permission_classes = [IsAuthenticated]

    @extend_schema(
        summary='Atualizar cotações via Yahoo Finance',
        description='Busca e retorna a cotação atual, moeda, dividend yield e frequência de dividendos para todos os ativos cadastrados, usando a API do Yahoo Finance.',
        responses={
            200: OpenApiResponse(
                description='Lista de ativos com dados atualizados',
                examples=[
                    OpenApiExample(
                        'Exemplo de resposta',
                        value={
                            'ativos_atualizados': [
                                {
                                    'codigo': 'AAPL',
                                    'nome': 'Apple Inc.',
                                    'cotacao': 213.55,
                                    'moeda': 'USD',
                                    'dividend_yield': 0.51,
                                    'frequencia': 1.04
                                }
                            ]
                        },
                        response_only=True
                    )
                ]
            )
        }
    )
    @action(detail=False, methods=['get'], url_path='atualizar')
    def atualizar_cotacoes(self, request):
        atualizados = []
        for asset in self.get_queryset():
            dados = buscar_dados_ativo(asset.codigo)
            if dados['cotacao']:
                atualizados.append({
                    'codigo': asset.codigo,
                    'nome': dados['nome'],
                    'cotacao': dados['cotacao'],
                    'moeda': dados['moeda'],
                    'dividend_yield': dados['dividend_yield'],
                    'frequencia': dados['frequencia'],
                })
        return Response({'ativos_atualizados': atualizados})


@extend_schema(tags=['Operações'])
class OperationViewSet(viewsets.ModelViewSet):
    queryset = Operation.objects.none()  # evita erro no router
    serializer_class = OperationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Operation.objects.filter(user=self.request.user)

    @extend_schema(
        summary='Criar operação de compra ou venda',
        examples=[
            OpenApiExample(
                'Exemplo de operação',
                value={
                    'tipo': 'COMPRA',
                    'ativo': 1,
                    'quantidade': 10,
                    'valor_compra': 150.0,
                    'data': '2024-01-01',
                    'dividendos': 5.0,
                    'categoria': 1,
                    'corretora': 1
                },
                request_only=True
            )
        ]
    )
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
