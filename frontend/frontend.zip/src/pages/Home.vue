<template>
  <v-container class="pa-4">
    <h1>Bem-vindo ao F.I.R.E.</h1>
    <p>Seu painel de controle de investimentos.</p>

    <v-btn color="primary" class="mt-4" to="/nova-operacao">
      + Nova operação
    </v-btn>
  </v-container>
</template>