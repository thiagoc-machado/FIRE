<template>
    <v-app>
        <v-navigation-drawer v-model="drawer" app>
            <v-list>
                <v-list-item
                    title="F.I.R.E."
                    class="text-h6 font-weight-bold"
                />

                <v-list-item link to="/">
                    <v-list-item-title>Dashboard</v-list-item-title>
                </v-list-item>

                <v-list-item link to="/nova-operacao">
                    <v-list-item-title>Nova operação</v-list-item-title>
                </v-list-item>

                <v-list-item link to="/operacoes">
                    <v-list-item-title>Operações</v-list-item-title>
                </v-list-item>
                <v-list-item link to="/ativos">
                    <v-list-item-title>Ativos</v-list-item-title>
                </v-list-item>
                <v-list-item link to="/corretoras">
                    <v-list-item-title>Corretoras</v-list-item-title>
                </v-list-item>
                <v-list-item link to="/categorias">
                    <v-list-item-title>categorias</v-list-item-title>
                </v-list-item>
                <v-list-item @click="logout" class="text-red">
                    <v-list-item-icon
                        ><v-icon color="red"
                            >mdi-logout</v-icon
                        ></v-list-item-icon
                    >
                    <v-list-item-title>Cerrar sesión</v-list-item-title>
                </v-list-item>
            </v-list>
        </v-navigation-drawer>

        <v-app-bar app color="primary" dark>
            <v-app-bar-nav-icon @click="toggleDrawer" />
            <v-toolbar-title>F.I.R.E.</v-toolbar-title>
        </v-app-bar>

        <v-main>
            <router-view />
        </v-main>
    </v-app>
</template>

<script setup>
    import { computed } from "vue";
    import { useStore } from "vuex";
    import { useRouter } from "vue-router";

    const router = useRouter();
    const logout = () => {
        store.dispatch("auth/logout");
        router.push("/login");
    };

    const store = useStore();
    const drawer = computed(() => store.state.drawer);
    const toggleDrawer = () => store.commit("toggleDrawer");
</script>
